
import React, { useState, useRef } from 'react';
import { RuleMode, AutomationRule } from '../types';
import { GoogleGenAI } from '@google/genai';

interface RuleFormProps {
  onSave: (rule: Omit<AutomationRule, 'id' | 'isActive'>) => void;
}

const RuleForm: React.FC<RuleFormProps> = ({ onSave }) => {
  const [triggerKeyword, setTriggerKeyword] = useState('');
  const [textMessage, setTextMessage] = useState('');
  const [linkText, setLinkText] = useState('');
  const [linkUrl, setLinkUrl] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [audioUrl, setAudioUrl] = useState('');
  const [followUpMsg, setFollowUpMsg] = useState('');
  const [followUpDelay, setFollowUpDelay] = useState(0);
  const [instantDelay, setInstantDelay] = useState(5);
  const [mode, setMode] = useState<RuleMode>(RuleMode.CUSTOMER);
  const [isExpanding, setIsExpanding] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert("File is too large! Maximum 5MB allowed.");
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setAudioUrl(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!triggerKeyword || !textMessage) {
      alert("Trigger Keyword and Text Message are required.");
      return;
    }

    onSave({
      triggerKeyword,
      sequence: {
        textMessage,
        linkText,
        linkUrl,
        imageUrl,
        audioUrl,
      },
      followUp: {
        message: followUpMsg,
        delayMinutes: followUpDelay,
      },
      instantDelaySec: instantDelay,
      mode,
    });

    // Reset Form
    setTriggerKeyword('');
    setTextMessage('');
    setLinkText('');
    setLinkUrl('');
    setImageUrl('');
    setAudioUrl('');
    setFollowUpMsg('');
    setFollowUpDelay(0);
  };

  const handleAIAssist = async () => {
    if (!triggerKeyword) {
      alert("Please enter a keyword first so I can suggest a reply!");
      return;
    }
    setIsGenerating(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Create a professional and friendly Messenger bot reply for the trigger keyword: "${triggerKeyword}". The reply should be in Bengali and English mix if appropriate. Keep it concise. Output only the text.`,
      });
      setTextMessage(response.text || '');
    } catch (error) {
      console.error(error);
      alert("AI suggestion failed. Check API Key configuration.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <button 
        onClick={() => setIsExpanding(!isExpanding)}
        className="w-full flex items-center justify-between p-4 text-gray-700 hover:bg-gray-50 transition border-b"
      >
        <div className="flex items-center space-x-2">
          <i className={`fa-solid ${isExpanding ? 'fa-minus' : 'fa-plus'} text-xs bg-gray-200 p-1 rounded-full`}></i>
          <span className="font-semibold">Create New Automation Rule</span>
        </div>
        <div className="text-xs text-gray-400">মেসেঞ্জার অটোমেশন সেটআপ করুন</div>
      </button>

      {isExpanding && (
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Trigger Keyword */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Trigger Keyword (ট্রিগার কি-ওয়ার্ড)</label>
            <input 
              type="text" 
              placeholder="e.g. loan, price, details"
              value={triggerKeyword}
              onChange={(e) => setTriggerKeyword(e.target.value)}
              className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-gray-50"
            />
          </div>

          {/* Reply Sequence */}
          <div className="bg-blue-50/30 p-5 rounded-xl border border-blue-100 space-y-5">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2 text-blue-600">
                <i className="fa-regular fa-comment-dots"></i>
                <h3 className="font-semibold">Reply Sequence (রিপ্লাই সিকোয়েন্স)</h3>
              </div>
              <button 
                type="button"
                onClick={handleAIAssist}
                disabled={isGenerating}
                className="text-xs bg-indigo-600 text-white px-3 py-1.5 rounded-full hover:bg-indigo-700 disabled:opacity-50 flex items-center space-x-1"
              >
                <i className="fa-solid fa-wand-magic-sparkles"></i>
                <span>{isGenerating ? 'Thinking...' : 'AI Suggest Text'}</span>
              </button>
            </div>

            {/* Step 1: Text Message */}
            <div>
              <label className="block text-xs font-bold text-gray-600 uppercase mb-1">1. Text Message</label>
              <textarea 
                rows={3}
                placeholder="প্রথমে এই মেসেজটি যাবে..."
                value={textMessage}
                onChange={(e) => setTextMessage(e.target.value)}
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white text-sm"
              />
            </div>

            {/* Step 2: Link & Image */}
            <div className="space-y-3">
              <label className="block text-xs font-bold text-gray-600 uppercase">2. Attachments (Link/Image)</label>
              <input 
                type="text"
                placeholder="লিংকের উপরের টেক্সট (যেমন: এপ্লাই করুন)"
                value={linkText}
                onChange={(e) => setLinkText(e.target.value)}
                className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white text-sm"
              />
              <input 
                type="url"
                placeholder="URL (https://...)"
                value={linkUrl}
                onChange={(e) => setLinkUrl(e.target.value)}
                className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white text-sm"
              />
              <input 
                type="text" 
                placeholder="ইমেজ লিংক (Image URL)..."
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white text-sm"
              />
            </div>

            {/* Step 3: Voice/Audio Upload */}
            <div>
              <label className="block text-xs font-bold text-gray-600 uppercase mb-2">3. Voice Message (ভয়েস মেসেজ আপলোড)</label>
              <div className="space-y-3">
                <input 
                  type="file" 
                  accept="audio/*" 
                  className="hidden" 
                  ref={fileInputRef}
                  onChange={handleAudioUpload}
                />
                <div className="flex items-center space-x-3">
                  <button 
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="bg-white border-2 border-dashed border-blue-200 hover:border-blue-400 text-blue-600 px-4 py-3 rounded-lg flex items-center space-x-2 transition w-full justify-center"
                  >
                    <i className="fa-solid fa-microphone-lines"></i>
                    <span className="font-semibold text-sm">{audioUrl ? 'Change Voice' : 'Upload Voice Message'}</span>
                  </button>
                  {audioUrl && (
                    <button 
                      type="button"
                      onClick={() => setAudioUrl('')}
                      className="bg-red-50 text-red-500 p-3 rounded-lg hover:bg-red-100 transition"
                    >
                      <i className="fa-solid fa-trash-can"></i>
                    </button>
                  )}
                </div>
                {audioUrl && (
                  <div className="bg-white p-2 rounded-lg border border-blue-100 flex items-center space-x-3">
                    <div className="text-blue-600"><i className="fa-solid fa-volume-high"></i></div>
                    <audio src={audioUrl} controls className="h-8 flex-1" />
                  </div>
                )}
                <p className="text-[10px] text-gray-400 italic">ভয়েস ফাইলটি আপলোড করলে গ্রাহকের কাছে মেসেঞ্জারের মতো প্লে বাটন সহ শো করবে।</p>
              </div>
            </div>
          </div>

          {/* Smart Follow-up */}
          <div className="bg-amber-50/30 p-5 rounded-xl border border-amber-100 space-y-4">
            <div className="flex items-center space-x-2 text-amber-600">
              <i className="fa-solid fa-clock"></i>
              <h3 className="font-semibold">Smart Follow-up (স্মার্ট ফলো-আপ)</h3>
            </div>
            <textarea 
              rows={2}
              placeholder="গ্রাহক রিপ্লাই না দিলে এই মেসেজটি যাবে..."
              value={followUpMsg}
              onChange={(e) => setFollowUpMsg(e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white text-sm"
            />
            <div className="flex items-center space-x-3">
              <label className="text-xs font-bold text-gray-600">অপেক্ষা করুন (Minutes)</label>
              <input 
                type="number" 
                value={followUpDelay}
                onChange={(e) => setFollowUpDelay(parseInt(e.target.value))}
                className="w-24 p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Configuration */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-600 mb-1">Instant Delay (Sec)</label>
              <input 
                type="number"
                value={instantDelay}
                onChange={(e) => setInstantDelay(parseInt(e.target.value))}
                className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-600 mb-1">Target Mode</label>
              <select 
                value={mode}
                onChange={(e) => setMode(e.target.value as RuleMode)}
                className="w-full p-2.5 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
              >
                <option value={RuleMode.CUSTOMER}>Customer Only</option>
                <option value={RuleMode.ADMIN}>Admin Only</option>
                <option value={RuleMode.GUEST}>Public/Guest</option>
              </select>
            </div>
          </div>

          <button 
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-100 transition transform active:scale-[0.98] flex items-center justify-center space-x-2"
          >
            <i className="fa-solid fa-floppy-disk"></i>
            <span>Save Automation Rule</span>
          </button>
        </form>
      )}
    </div>
  );
};

export default RuleForm;
