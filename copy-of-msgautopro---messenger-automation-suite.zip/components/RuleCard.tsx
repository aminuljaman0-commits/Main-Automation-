
import React from 'react';
import { AutomationRule } from '../types';

interface RuleCardProps {
  rule: AutomationRule;
  onDelete: () => void;
}

const RuleCard: React.FC<RuleCardProps> = ({ rule, onDelete }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 group hover:border-blue-200 transition">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 font-bold">
            {rule.triggerKeyword.charAt(0).toUpperCase()}
          </div>
          <div>
            <h3 className="font-bold text-gray-800">Trigger: <span className="text-blue-600">{rule.triggerKeyword}</span></h3>
            <div className="flex space-x-2 mt-1">
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 font-bold uppercase">
                {rule.mode}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-gray-100 text-gray-700 font-bold uppercase">
                {rule.instantDelaySec}s Delay
              </span>
            </div>
          </div>
        </div>
        <div className="flex space-x-2">
          <button 
            onClick={onDelete}
            className="p-2 text-gray-300 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
          >
            <i className="fa-solid fa-trash-can"></i>
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {/* Text Part */}
        <div className="bg-gray-50 p-3 rounded-2xl rounded-tl-none inline-block max-w-[90%] border border-gray-100">
          <p className="text-sm text-gray-700 whitespace-pre-wrap">{rule.sequence.textMessage}</p>
        </div>

        {/* Audio Part - Messenger Style */}
        {rule.sequence.audioUrl && (
          <div className="flex flex-col space-y-1">
            <div className="flex items-center space-x-3 bg-blue-600 text-white p-3 rounded-3xl rounded-tl-none w-[280px] shadow-sm">
              <button className="w-10 h-10 rounded-full bg-white text-blue-600 flex items-center justify-center hover:bg-blue-50 transition shrink-0">
                <i className="fa-solid fa-play ml-1"></i>
              </button>
              <div className="flex-1 flex items-center space-x-1 overflow-hidden opacity-90">
                {/* Simulated Waveform */}
                {[...Array(18)].map((_, i) => (
                  <div 
                    key={i} 
                    className="w-1 bg-white rounded-full" 
                    style={{ height: `${Math.random() * 20 + 5}px` }}
                  />
                ))}
              </div>
              <span className="text-[10px] font-medium pr-1 shrink-0">0:45</span>
            </div>
            <div className="pl-3">
              <span className="text-[9px] text-gray-400 font-bold uppercase tracking-wider">Voice Attachment</span>
            </div>
          </div>
        )}

        {/* Link Part */}
        {rule.sequence.linkUrl && (
          <div className="pl-3 border-l-2 border-blue-200">
            <a 
              href={rule.sequence.linkUrl} 
              target="_blank" 
              rel="noreferrer"
              className="text-xs text-blue-600 hover:underline flex items-center space-x-2 font-medium"
            >
              <i className="fa-solid fa-up-right-from-square text-[10px]"></i>
              <span>{rule.sequence.linkText || 'Visit Link'}</span>
            </a>
          </div>
        )}

        {/* Follow-up Indicator */}
        {rule.followUp.message && (
          <div className="bg-amber-50 p-3 rounded-xl border border-amber-100">
            <div className="flex items-center space-x-2 text-amber-600 mb-1">
              <i className="fa-solid fa-clock text-[10px]"></i>
              <span className="text-[10px] font-bold uppercase">Follow-up in {rule.followUp.delayMinutes}m</span>
            </div>
            <p className="text-xs text-amber-800 line-clamp-1 italic">"{rule.followUp.message}"</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default RuleCard;
