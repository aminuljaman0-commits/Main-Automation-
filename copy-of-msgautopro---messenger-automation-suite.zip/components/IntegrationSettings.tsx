
import React, { useState } from 'react';
import { IntegrationConfig, AutomationRule } from '../types';

interface IntegrationSettingsProps {
  config: IntegrationConfig;
  setConfig: React.Dispatch<React.SetStateAction<IntegrationConfig>>;
  rules: AutomationRule[];
}

const IntegrationSettings: React.FC<IntegrationSettingsProps> = ({ config, setConfig, rules }) => {
  const [isSyncing, setIsSyncing] = useState(false);

  const handleChange = (field: keyof IntegrationConfig, value: string) => {
    setConfig(prev => ({ ...prev, [field]: value }));
  };
  
  const handleSync = async () => {
    if (!config.webhookUrl || !config.syncPassword) {
      alert("Please set your Callback URL and Sync Password first!");
      return;
    }
    
    setIsSyncing(true);
    
    // The server needs a clean URL, without /webhook
    const baseUrl = config.webhookUrl.replace('/webhook', '');
    const syncUrl = `${baseUrl}/update-rules`;

    const exportableRules = rules.map(rule => ({
      triggerKeyword: rule.triggerKeyword,
      textMessage: rule.sequence.textMessage,
    }));
    
    try {
      const response = await fetch(syncUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          password: config.syncPassword,
          rules: exportableRules
        })
      });

      if (response.ok) {
        alert('Sync Successful! Your rules are now live on the server.');
      } else {
        const errorData = await response.json();
        alert(`Sync Failed: ${errorData.message || 'Check server logs and password.'}`);
      }
    } catch (error) {
      console.error('Sync error:', error);
      alert('Sync Failed. Could not connect to the server. Is the URL correct?');
    } finally {
      setIsSyncing(false);
    }
  };
  
  const serverCode = `const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const app = express();
app.use(express.json());

// --- CONFIGURATION ---
const PAGE_ACCESS_TOKEN = process.env.PAGE_ACCESS_TOKEN;
const VERIFY_TOKEN = process.env.VERIFY_TOKEN;
const SYNC_PASSWORD = process.env.SYNC_PASSWORD;
const RULES_FILE_PATH = path.join(__dirname, 'rules.json');

// --- LOAD RULES FROM FILE ---
let automationRules = [];
try {
  if (fs.existsSync(RULES_FILE_PATH)) {
    const rawData = fs.readFileSync(RULES_FILE_PATH);
    automationRules = JSON.parse(rawData);
    console.log('Rules loaded from rules.json');
  } else {
    console.log('rules.json not found, starting with empty rules.');
  }
} catch (error) {
  console.error('Error loading rules:', error);
}

// --- API ENDPOINTS ---

// 1. Webhook Verification (for Facebook)
app.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  if (mode === 'subscribe' && token === VERIFY_TOKEN) {
    res.status(200).send(challenge);
  } else {
    res.sendStatus(403);
  }
});

// 2. Message Handling (for Facebook)
app.post('/webhook', (req, res) => {
  const body = req.body;
  if (body.object === 'page') {
    body.entry.forEach(entry => {
      const webhookEvent = entry.messaging[0];
      if (webhookEvent.message && webhookEvent.message.text) {
        const senderId = webhookEvent.sender.id;
        const receivedMessage = webhookEvent.message.text.toLowerCase();
        
        const matchedRule = automationRules.find(rule => 
          receivedMessage.includes(rule.triggerKeyword.toLowerCase())
        );

        if (matchedRule) {
          sendTextMessage(senderId, matchedRule.textMessage);
        }
      }
    });
    res.status(200).send('EVENT_RECEIVED');
  } else {
    res.sendStatus(404);
  }
});

// 3. Update Rules Endpoint (for Dashboard Sync)
app.post('/update-rules', (req, res) => {
  const { password, rules } = req.body;

  if (password !== SYNC_PASSWORD) {
    return res.status(403).json({ message: 'Invalid sync password' });
  }
  if (!Array.isArray(rules)) {
    return res.status(400).json({ message: 'Invalid rules format' });
  }

  try {
    fs.writeFileSync(RULES_FILE_PATH, JSON.stringify(rules, null, 2));
    automationRules = rules; // Update in-memory rules
    console.log('Rules updated successfully!');
    res.status(200).json({ message: 'Rules updated successfully' });
  } catch (error) {
    console.error('Error saving rules:', error);
    res.status(500).json({ message: 'Failed to save rules on server' });
  }
});

// --- HELPER FUNCTION ---
async function sendTextMessage(recipientId, messageText) {
  const messageData = { recipient: { id: recipientId }, message: { text: messageText } };
  try {
    await axios.post('https://graph.facebook.com/v19.0/me/messages?access_token=' + PAGE_ACCESS_TOKEN, messageData);
  } catch (error) {
    console.error('Unable to send message:', error.response.data);
  }
}

app.listen(process.env.PORT || 3000, () => console.log('Server is live!'));
`;

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      <div className="bg-white rounded-2xl shadow-sm border p-8 space-y-8 animate-fade-in">
        <div className="border-b pb-4">
          <h2 className="text-2xl font-bold text-gray-800">API Integration</h2>
          <p className="text-gray-500 text-sm">ফেসবুক মেসেঞ্জার এপিআই এবং সার্ভারের সাথে কানেক্ট করুন।</p>
        </div>

        <div className="space-y-4">
          <h3 className="font-bold text-gray-800">Messenger API & Server</h3>
           <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Sync Password</label>
            <input 
              type="password" 
              value={config.syncPassword || ''} 
              onChange={(e) => handleChange('syncPassword', e.target.value)}
              className="w-full p-3 border rounded-xl bg-gray-50" 
              placeholder="সার্ভারের সাথে কানেক্ট করার গোপন পাসওয়ার্ড"
            />
             <p className="text-xs text-gray-500 mt-1">এই পাসওয়ার্ডটি আপনার সার্ভার এবং ড্যাশবোর্ডে একই হতে হবে।</p>
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Verify Token</label>
            <input 
              type="text" 
              value={config.verifyToken} 
              onChange={(e) => handleChange('verifyToken', e.target.value)}
              className="w-full p-3 border rounded-xl bg-gray-50" 
              placeholder="e.g. my_secret_bot_123"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Callback URL (আপনার সার্ভার লিঙ্ক)</label>
            <input 
              type="text" 
              value={config.webhookUrl} 
              onChange={(e) => handleChange('webhookUrl', e.target.value)}
              className="w-full p-3 border rounded-xl bg-gray-50" 
              placeholder="https://your-server.glitch.me/webhook"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Page Access Token</label>
            <textarea 
              rows={3} 
              value={config.pageAccessToken} 
              onChange={(e) => handleChange('pageAccessToken', e.target.value)}
              className="w-full p-3 border rounded-xl bg-gray-50 font-mono text-xs" 
              placeholder="EAA..."
            />
          </div>
        </div>
        
        <div className="flex space-x-3">
          <button 
            onClick={() => alert("Settings Saved Locally!")}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-lg transition"
          >
            Save Settings
          </button>
           <button 
            onClick={handleSync}
            disabled={isSyncing}
            className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-4 rounded-xl shadow-lg transition flex items-center justify-center space-x-2 disabled:opacity-50"
          >
            {isSyncing ? (
              <i className="fa-solid fa-spinner fa-spin"></i>
            ) : (
              <i className="fa-solid fa-cloud-arrow-up"></i>
            )}
            <span>{isSyncing ? 'Syncing...' : 'Sync to Server'}</span>
          </button>
        </div>
      </div>

      <div className="bg-slate-900 rounded-2xl overflow-hidden shadow-xl border border-slate-800">
        <div className="bg-slate-800 px-6 py-4 flex justify-between items-center border-b border-slate-700">
          <div className="flex items-center space-x-2">
            <span className="w-3 h-3 rounded-full bg-red-500"></span>
            <span className="w-3 h-3 rounded-full bg-amber-500"></span>
            <span className="w-3 h-3 rounded-full bg-green-500"></span>
            <span className="text-slate-400 text-xs font-mono ml-4">server.js (Node.js/Glitch)</span>
          </div>
          <button 
            onClick={() => { navigator.clipboard.writeText(serverCode); alert("Code Copied!"); }}
            className="text-xs bg-slate-700 hover:bg-slate-600 text-white px-3 py-1.5 rounded-md transition"
          >
            Copy Server Code
          </button>
        </div>
        <div className="p-6">
           <div className="bg-blue-900/50 text-blue-200 border border-blue-700 p-4 rounded-lg space-y-2 text-sm mb-4">
              <h4 className="font-bold text-base">কিভাবে কাজ করাবেন (স্বয়ংক্রিয় সিস্টেম):</h4>
              <p>১. নিচের সম্পূর্ণ সার্ভার কোডটি কপি করে আপনার Glitch প্রজেক্টের `server.js` ফাইলে পেস্ট করুন।</p>
              <p>২. Glitch প্রজেক্টের `.env` ফাইলে `SYNC_PASSWORD` নামে একটি নতুন ভ্যারিয়েবল যোগ করে একটি গোপন পাসওয়ার্ড দিন।</p>
              <p>৩. ড্যাশবোর্ডের 'Sync Password' ফিল্ডে একই পাসওয়ার্ডটি দিন এবং সেভ করুন।</p>
              <p>৪. এখন থেকে রুল পরিবর্তন করে শুধু **'Sync to Server'** বাটনে ক্লিক করলেই আপনার অটোমেশন লাইভ হয়ে যাবে!</p>
           </div>
          <pre className="text-indigo-300 text-[11px] font-mono leading-relaxed overflow-x-auto whitespace-pre">
            {serverCode}
          </pre>
        </div>
      </div>
    </div>
  );
};

export default IntegrationSettings;
