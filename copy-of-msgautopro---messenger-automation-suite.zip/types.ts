
export enum RuleMode {
  CUSTOMER = 'Customer',
  ADMIN = 'Admin',
  GUEST = 'Guest'
}

export interface ReplySequence {
  textMessage: string;
  linkText?: string;
  linkUrl?: string;
  imageUrl?: string;
  audioUrl?: string;
}

export interface SmartFollowUp {
  message: string;
  delayMinutes: number;
}

export interface AutomationRule {
  id: string; // Changed back to string for localStorage
  triggerKeyword: string;
  sequence: ReplySequence;
  followUp: SmartFollowUp;
  instantDelaySec: number;
  mode: RuleMode;
  isActive: boolean;
  created_at?: string;
}

export interface IntegrationConfig {
  pageAccessToken: string;
  verifyToken: string;
  webhookUrl: string;
  syncPassword?: string;
}
