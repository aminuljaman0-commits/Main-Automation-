
import React, { useState, useEffect } from 'react';
import { AutomationRule, RuleMode, IntegrationConfig } from './types';
import RuleForm from './components/RuleForm';
import RuleCard from './components/RuleCard';
import IntegrationSettings from './components/IntegrationSettings';
import Login from './components/Login';

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('is_logged_in') === 'true';
  });
  
  const [activeTab, setActiveTab] = useState<'automation' | 'settings'>('automation');
  
  const [rules, setRules] = useState<AutomationRule[]>(() => {
    const saved = localStorage.getItem('messenger_rules');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [welcomeMessage, setWelcomeMessage] = useState<string>(() => {
    const saved = localStorage.getItem('messenger_welcome');
    return saved ? JSON.parse(saved) : "স্বাগতম! আমরা আপনার মেসেজের অপেক্ষায় আছি।";
  });

  const [config, setConfig] = useState<IntegrationConfig>(() => {
    const saved = localStorage.getItem('messenger_config');
    return saved ? JSON.parse(saved) : { 
      pageAccessToken: '', 
      verifyToken: 'messenger_bot_verify_v1', 
      webhookUrl: '',
      syncPassword: '',
    };
  });

  useEffect(() => {
    localStorage.setItem('messenger_config', JSON.stringify(config));
  }, [config]);
  
  useEffect(() => {
    localStorage.setItem('messenger_rules', JSON.stringify(rules));
  }, [rules]);
  
  useEffect(() => {
    localStorage.setItem('messenger_welcome', JSON.stringify(welcomeMessage));
  }, [welcomeMessage]);

  useEffect(() => {
    localStorage.setItem('is_logged_in', isLoggedIn.toString());
  }, [isLoggedIn]);

  const handleLogin = () => setIsLoggedIn(true);
  const handleLogout = () => setIsLoggedIn(false);

  const handleSaveRule = (newRuleData: Omit<AutomationRule, 'id' | 'isActive'>) => {
    const newRule: AutomationRule = {
      ...newRuleData,
      id: Date.now().toString(),
      isActive: true,
      created_at: new Date().toISOString()
    };
    setRules([newRule, ...rules]);
  };

  const handleDeleteRule = (id: string) => {
    setRules(rules.filter(r => r.id !== id));
  };

  const handleUpdateWelcomeMessage = () => {
    alert('Welcome message updated locally!');
    // The useEffect for welcomeMessage handles the saving.
  }
  
  const handleExportRules = () => {
    if (rules.length === 0) {
      alert("কোনো রুল তৈরি করা হয়নি।");
      return;
    }
    // The simple server template only uses these two fields.
    const exportableRules = rules.map(rule => ({
      triggerKeyword: rule.triggerKeyword,
      textMessage: rule.sequence.textMessage,
    }));
    
    const rulesJson = JSON.stringify(exportableRules, null, 2);
    navigator.clipboard.writeText(rulesJson);
    alert('Rules copied to clipboard! Now paste this into your server.js file.');
  };

  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="flex flex-col min-h-screen bg-slate-50">
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center text-white">
              <i className="fa-brands fa-facebook-messenger text-xl"></i>
            </div>
            <h1 className="text-xl font-bold text-gray-800">MsgAutoPro</h1>
          </div>
          <div className="flex items-center space-x-4">
            <nav className="flex space-x-1">
              <button 
                onClick={() => setActiveTab('automation')}
                className={`px-4 py-2 rounded-md transition ${activeTab === 'automation' ? 'bg-blue-50 text-blue-600 font-semibold' : 'text-gray-600 hover:bg-gray-100'}`}
              >
                Automation
              </button>
              <button 
                onClick={() => setActiveTab('settings')}
                className={`px-4 py-2 rounded-md transition ${activeTab === 'settings' ? 'bg-blue-50 text-blue-600 font-semibold' : 'text-gray-600 hover:bg-gray-100'}`}
              >
                Settings
              </button>
            </nav>
            <button 
              onClick={handleLogout}
              className="text-red-500 font-medium hover:bg-red-50 px-3 py-1.5 rounded-md transition flex items-center space-x-1"
            >
              <i className="fa-solid fa-right-from-bracket"></i>
              <span>Logout</span>
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-8">
        {activeTab === 'automation' ? (
          <div className="space-y-8">
            <section className="bg-white rounded-xl shadow-sm border border-blue-100 p-6">
              <div className="flex items-center space-x-2 mb-4 text-blue-600">
                <i className="fa-solid fa-thumbs-up"></i>
                <h2 className="font-semibold text-lg">Greetings (Welcome Message)</h2>
              </div>
              <p className="text-sm text-gray-500 mb-3">মেসেজ (১০ সেকেন্ড টাইপিং দেখানোর পর যাবে)</p>
              <div className="flex space-x-3">
                <div className="flex-1 relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                    <i className="fa-solid fa-building-columns"></i>
                  </span>
                  <input 
                    type="text" 
                    value={welcomeMessage}
                    onChange={(e) => setWelcomeMessage(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-gray-50"
                  />
                </div>
                <button 
                  onClick={handleUpdateWelcomeMessage}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg flex items-center space-x-2 transition"
                >
                  <i className="fa-solid fa-cloud-arrow-up"></i>
                  <span>Update</span>
                </button>
              </div>
            </section>

            <section>
              <RuleForm onSave={handleSaveRule} />
            </section>

            <section className="space-y-4">
              <div className="flex items-center justify-between text-gray-700 font-semibold border-b pb-2">
                <div className="flex items-center space-x-2">
                  <i className="fa-solid fa-list-ul"></i>
                  <h2>Active Rules ({rules.length})</h2>
                </div>
                <button 
                  onClick={handleExportRules}
                  className="text-xs bg-gray-500 hover:bg-gray-600 text-white px-3 py-1.5 rounded-full flex items-center space-x-2 transition transform active:scale-95"
                >
                  <i className="fa-solid fa-file-export"></i>
                  <span>Export (Manual)</span>
                </button>
              </div>
              {rules.length === 0 ? (
                <div className="text-center py-12 bg-white rounded-xl border-2 border-dashed border-gray-200">
                  <p className="text-gray-400">No automation rules created yet.</p>
                </div>
              ) : (
                rules.map(rule => (
                  <RuleCard key={rule.id} rule={rule} onDelete={() => handleDeleteRule(rule.id)} />
                ))
              )}
            </section>
          </div>
        ) : (
          <IntegrationSettings config={config} setConfig={setConfig} rules={rules} />
        )}
      </main>

      <footer className="bg-white border-t py-6 text-center text-gray-500 text-sm mt-12">
        &copy; 2024 MsgAutoPro - Professional Messenger Automation
      </footer>
    </div>
  );
};

export default App;
